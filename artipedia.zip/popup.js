function withActiveTab(cb){
  chrome.tabs.query({active: true, currentWindow: true}, tabs => {
    if (tabs && tabs[0]) cb(tabs[0].id);
  });
}

function refreshStatus(){
  withActiveTab(tabId => {
    chrome.tabs.sendMessage(tabId, {command: "getStatus"}, res => {
      if (!res) return;
      document.getElementById('status').textContent = res.statusText || (res.running ? "Đang chạy" : "Đã dừng");
      document.getElementById('countdown').textContent = res.countdown ?? 0;
    });
  });
}

document.getElementById('start').addEventListener('click', () => {
  withActiveTab(tabId => {
    chrome.tabs.sendMessage(tabId, {command: "start"}, res => {
      refreshStatus();
    });
  });
});

document.getElementById('stop').addEventListener('click', () => {
  withActiveTab(tabId => {
    chrome.tabs.sendMessage(tabId, {command: "stop"}, res => {
      refreshStatus();
    });
  });
});

// Nhận trạng thái realtime từ content (khi popup đang mở)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "statusUpdate") {
    document.getElementById('status').textContent = msg.statusText || "";
    document.getElementById('countdown').textContent = msg.countdown ?? 0;
  }
});

// Lấy trạng thái khi mở popup
refreshStatus();
// Cập nhật định kỳ phòng trường hợp popup mở lâu
setInterval(refreshStatus, 1500);
