// ===== Config =====
const videoSelectors = [
  '#__next > main > div.jsx-2f273c7328ee0c1d.section-padding > div > div.jsx-2f273c7328ee0c1d.card-style-grid > div > div:nth-child(11) > div > div.jsx-f174233d83cae69a.iq-card.bg-black.card-hover > div > div.jsx-f174233d83cae69a.card-body.p-3',
  '#__next > main > div.jsx-2f273c7328ee0c1d.section-padding > div > div.jsx-2f273c7328ee0c1d.card-style-grid > div > div:nth-child(10) > div > div.jsx-f174233d83cae69a.iq-card.bg-black.card-hover > div > div.jsx-f174233d83cae69a.card-body.p-3',
  '#__next > main > div.jsx-2f273c7328ee0c1d.section-padding > div > div.jsx-2f273c7328ee0c1d.card-style-grid > div > div:nth-child(9) > div > div.jsx-f174233d83cae69a.iq-card.bg-black.card-hover > div > div.jsx-f174233d83cae69a.card-body.p-3',
  '#__next > main > div.jsx-2f273c7328ee0c1d.section-padding > div > div.jsx-2f273c7328ee0c1d.card-style-grid > div > div:nth-child(8) > div > div.jsx-f174233d83cae69a.iq-card.bg-black.card-hover > div > div.jsx-f174233d83cae69a.card-body.p-3',
  '#__next > main > div.jsx-2f273c7328ee0c1d.section-padding > div > div.jsx-2f273c7328ee0c1d.card-style-grid > div > div:nth-child(6) > div > div.jsx-f174233d83cae69a.iq-card.bg-black.card-hover > div > div.jsx-f174233d83cae69a.card-body.p-3',
  '#__next > main > div.jsx-2f273c7328ee0c1d.section-padding > div > div.jsx-2f273c7328ee0c1d.card-style-grid > div > div:nth-child(12) > div > div.jsx-f174233d83cae69a.iq-card.bg-black.card-hover > div > div.jsx-f174233d83cae69a.card-body.p-3'
];
const claimButtonSelector = 'button.fw-bold.pulse-animation.btn.btn-warning.btn-lg';
const reloadButtonSelector = '#__next > main > div.section-padding > div > div > button';
const interruptedSelector = 'div.text-white.px-3.py-1.rounded-pill.small.d-flex.align-items-center.gap-2';
const closePopupSelector = 'body > div.fade.artipedia-video-modal.modal.show > div > div > div > div:nth-child(1) > div.jsx-8c4eaabccfb28791.position-absolute.top-0.end-0.m-3.d-flex.align-items-center.gap-2 > button';

// ===== State =====
let running = false;
let countdownInterval = null;
let lastStatusText = 'Idle';
let lastCountdown = 0;

// ===== Overlay panel on page =====
(function ensurePanel(){
  if (document.getElementById('auto-panel')) return;
  const panel = document.createElement('div');
  panel.id = 'auto-panel';
  panel.style.position = 'fixed';
  panel.style.bottom = '20px';
  panel.style.right = '20px';
  panel.style.background = 'rgba(0,0,0,0.8)';
  panel.style.color = 'white';
  panel.style.padding = '12px';
  panel.style.borderRadius = '10px';
  panel.style.fontSize = '14px';
  panel.style.zIndex = '999999';
  panel.innerHTML = `
    <div>Trạng thái: <span id="auto-status" style="color:#32cd32">Stopped</span></div>
    <div>⏳ <span id="auto-countdown" style="color:#32cd32">0</span>s</div>
  `;
  document.body.appendChild(panel);
})();

const statusEl = () => document.getElementById('auto-status');
const countdownEl = () => document.getElementById('auto-countdown');

function pushStatus(text, color='lime', countdown=lastCountdown){
  lastStatusText = text;
  lastCountdown = countdown;
  const s = statusEl(); const c = countdownEl();
  if (s){ s.textContent = text; s.style.color = color; }
  if (c){ c.textContent = String(countdown); c.style.color = '#32cd32'; }
  // gửi về popup nếu đang mở
  try {
    chrome.runtime.sendMessage({ type: 'statusUpdate', statusText: text, countdown });
  } catch(e){ /* ignore when popup closed */ }
}

function logStatus(text, color='lime'){ console.log('%c' + text, 'color:'+color); pushStatus(text, color); }

function countdown(seconds, checkInterrupted=false){
  return new Promise(resolve => {
    clearInterval(countdownInterval);
    let remaining = Math.max(0, Math.ceil(seconds));
    lastCountdown = remaining;
    pushStatus(lastStatusText, 'lime', remaining);
    countdownInterval = setInterval(() => {
      if (!running){
        clearInterval(countdownInterval);
        resolve('stopped'); return;
      }
      remaining -= 1;
      lastCountdown = remaining;
      pushStatus(lastStatusText, 'lime', remaining);

      if (checkInterrupted){
        const interruptedEl = document.querySelector(interruptedSelector);
        if (interruptedEl && interruptedEl.innerText.includes('🚫 Interrupted. Restart to earn points')){
          clearInterval(countdownInterval);
          logStatus('🚫 Video bị gián đoạn, đóng popup...', 'red', remaining);
          const closeBtn = document.querySelector(closePopupSelector);
          if (closeBtn) closeBtn.click();
          resolve('interrupted'); return;
        }
      }

      if (remaining <= 0){
        clearInterval(countdownInterval);
        resolve('done');
      }
    }, 1000);
  });
}

function waitForPopupClosed(){
  return new Promise(resolve => {
    const it = setInterval(() => {
      const popup = document.querySelector('.modal-body');
      if (!popup){ clearInterval(it); resolve(); }
    }, 600);
  });
}

// ===== Main flow =====
async function autoLoop(){
  while (running){
    // Check reload if visible
    const reloadBtn = document.querySelector(reloadButtonSelector);
    if (reloadBtn){
      logStatus('🔄 Tìm thấy nút reload, chờ 2s...', 'yellow');
      await countdown(2);
      if (!running) break;
      if (reloadBtn && document.body.contains(reloadBtn)){
        logStatus('🔄 Đang reload...', 'yellow');
        reloadBtn.click();
        pushStatus('⏳ Chờ 10s sau reload...', 'yellow', 10);
        await countdown(10);
      }
    }

    const selector = videoSelectors[Math.floor(Math.random()*videoSelectors.length)];
    const videoCard = document.querySelector(selector);

    if (!videoCard){
      logStatus('❌ Không tìm thấy video, thử lại...', 'red');
      await countdown(5);
      continue;
    }

    logStatus('🎬 Đang mở video...', 'lime');
    videoCard.click();
    await countdown(5);

    // Đảm bảo popup xuất hiện
    if (!document.querySelector('.modal-body')){
      logStatus('⚠️ Popup không hiện, thử lại...', 'red');
      videoCard.click();
      await countdown(5);
    }

    const video = document.querySelector('.modal-body video');
    if (!(video && video.duration)){
      logStatus('❌ Không tìm thấy video trong popup! → Reload', 'red');
      const rb = document.querySelector(reloadButtonSelector);
      if (rb){
        await countdown(2);
        rb.click();
        await countdown(10);
      } else {
        await countdown(10);
      }
      continue;
    }

    const duration = Math.ceil(video.duration);
    logStatus('▶️ Đang xem video...', 'lime', duration);
    const watchResult = await countdown(duration, true);
    if (watchResult === 'interrupted'){ await countdown(5); continue; }
    if (watchResult === 'stopped') break;

    // Claim reward
    const claimBtn = document.querySelector(claimButtonSelector);
    if (claimBtn){
      logStatus('💰 Claim reward...', 'yellow');
      claimBtn.click();
      await countdown(15);
      await waitForPopupClosed();
    }

    logStatus('✅ Xong 1 vòng, nghỉ 7s...', 'lime', 7);
    await countdown(7);
  }
  pushStatus('⏸ Đã dừng', 'orange', 0);
}

// ===== Messaging with popup =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.command === 'start'){
    if (!running){
      running = true;
      pushStatus('▶️ Bắt đầu chạy...', 'lime', 0);
      autoLoop();
    }
    sendResponse?.({ running, statusText: lastStatusText, countdown: lastCountdown });
  } else if (msg?.command === 'stop'){
    running = false;
    sendResponse?.({ running, statusText: '⏸ Đã dừng', countdown: 0 });
  } else if (msg?.command === 'getStatus'){
    sendResponse?.({ running, statusText: lastStatusText, countdown: lastCountdown });
  }
});
